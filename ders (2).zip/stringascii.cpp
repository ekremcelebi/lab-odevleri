#include <iostream>

using namespace std;

int main() {
    string kelime = "abdc"

    int a = 1;
    a = (double) a;

    for (char harf: kelime) {
        cout << "harf: "<< harf <<(int) << endl;
    }
}
