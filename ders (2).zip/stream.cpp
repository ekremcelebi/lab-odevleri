#include <iostream>
#include <sstream>

using namespace std;

int main() {
    string cümle = "ic içe döngüler";

    stringstream c(cümle);

    string kelime;

    while (c >> kelime) {
        int count  =0;
        for (char i : kelime) {
            count++;
        }
        cout << kelime << "\t" << count << endl;
    }
}
