#include <iostream>

using namespace std;

int main () {
 int ilk,son, toplam = 0 count;

 cout << " ilk sayıyı gir " ;
 cin << son;

 cout << " son sayıyı gir:" ;
 cin >> son;

 int curr =min(ilk,son);
 int target = max(ilk,son);

 while (curr <= target) {
    toplam += curr;
    count++;
    curr++;
 }

 cout << "toplam: " <<  toplam << endl;
 cout << "ortalma:" <<toplam/count;

}

 