#include <iostream>

using namespace std;

int main() {
    int count = 0;
    cout << "sayi\tkare\tkup" << endl;

    while (count <= 10) {
        cout << count << "\t" << count*count  << ""
    