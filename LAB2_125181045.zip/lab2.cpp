#include  <iostream>
using namespace std;

int main() {
    int sicaklik;

    cout << "lütfen bi sicaklik değeri giriniz:" << endl ;
    cin >> sicaklik;

    if(sicaklik <= 0) {
        cout <<  "çok soğuk" <<endl;
    }
        else if (sicaklik <= 15) {
        cout << "havasoguk:iyi giyin."<<endl;
    }
        else if (sicaklik <= 25) {
        cout << "havailik:güzel hava ."<<endl;
    }
        else {
        cout <<"hava cok sicak, gezilcek hava" <<endl;
    }
    
    return 0;
}