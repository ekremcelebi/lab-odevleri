#include  <iostream>
using namespace std;

int main() {
   int sayi;
   
   cout << " bir sayi giriniz" << endl;
   cin  >> sayi;
   if (sayi%2) {
      cout <<" cift" << endl; } 
      else {
         cout << " tek" << endl;
      }
return 0;
}



