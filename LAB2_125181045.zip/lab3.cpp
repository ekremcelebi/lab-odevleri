#include  <iostream>
using namespace std;

int main() {

    char op;
    float n1;
    float n2;

    cout << "please enter the first number" << endl;
    cin  >> n1;
    cout  << "please enter the first number" << endl;
    cin >> n2; 

    cout << "please enter the operation you want to do [ A,M,D,S ]" << endl;

    switch (op) {
        case 'A':
            cout << n1 + n2 << endl;
            break;
        case 'M':
            cout << n1 * n2 << endl;
            break;
        case 'D':
            cout << n1 / n2 << endl;
            break;
        case 'S':
            cout << n1 - n2 << endl;
            break;
        default:
            cout << "invalid, try again" << endl;
            break;
    }

}