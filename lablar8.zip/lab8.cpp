#include <iostream>
#include <string>
#include <cmath>
using namespace std;

class Nokta {
    int x, y;

public:
    // TODO 1: x=0, y=0 başlatan default constructor yaz
    // (initializer list kullan)
    Nokta() : x(0), y(0) {}

    // TODO 2: x ve y'yi parametreden alan constructor yaz
    // (initializer list kullan)
    Nokta(int a, int b) : x(a), y(b) {}

    // TODO 3: void yazdir() – "(x, y)" formatında ekrana yaz
    void yazdir() const {
        cout << "(" << x << ", " << y << ")" << endl;
    }

    // TODO 4: double uzaklik(Nokta diger)
    // iki nokta arası mesafeyi döndür
    // sqrt( (x2-x1)^2 + (y2-y1)^2 )

    double uzaklik(Nokta d) const {
        return sqrt(pow(d.x - x, 2) + pow(d.y - y, 2));
    }
};

int main() {
    Nokta p1;           // default → (0, 0)
    Nokta p2(3, 4);     // parametreli → (3, 4)

    p1.yazdir();        // (0, 0)
    p2.yazdir();        // (3, 4)

    cout << p1.uzaklik(p2) << endl;  // 5

    return 0;
}

/*
Aşağıdaki kodun çıktısı ne olur?

Nokta a;
Nokta b(6, 8);
Nokta c = b;

a.yazdir();
b.yazdir();
c.yazdir();

cout << a.uzaklik(b) << endl;

CEVAP:

(0, 0)
(6, 8)
(6, 8)
10

*/