#include <iostream>

using namespace std;

class Dikdortgen {
    double en, boy;
public:
    // TODO 1: varsayılan argümanlı constructor  (en=1.0, boy=1.0)
    Dikdortgen(double e = 1.0, double b = 1.0) : en(e), boy(b) {}
    
    // TODO 2: double alan() const
    double alan() const { 
        return en * boy;
    }
    
    // TODO 3: double cevre() const
    double cevre() const {
        return 2 * (en + boy);
    }
    
    // TODO 4: void yazdir() const  – en, boy, alan, cevre yazdır
    void yazdir() const {
        cout << "en: " << en  << endl;
        cout << "boy: " << boy  << endl;
        cout << "alan: " << alan()  << endl;
        cout << "cevre: " << cevre()  << endl;
    }
};

int main() {
    Dikdortgen d1;
    Dikdortgen d2(4.0, 2.5);
    d1.yazdir();
    d2.yazdir();
}