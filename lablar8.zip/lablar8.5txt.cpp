	s2 = s1 atandiğinda grade pointer'i kopyalanir.

•	*s2.grade = 50 yazdiğinda s1.grade da değişir, neden açiklayin?
Cevap:

•	Program bitişinde hangi hata oluşur?
Cevap: