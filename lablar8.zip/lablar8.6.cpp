#include <iostream>
using namespace std;

class IntDizisi {
    int* veri;
    int  boyut;
public:
    IntDizisi(int b);               // new int[b]
    IntDizisi(const IntDizisi& d);  // deep copy
    ~IntDizisi();                   // delete[]

    void doldur(int baslangic);     // veri[i] = baslangic + i
    void yazdir() const;
    int  getBoyut() const;

    friend int main();
};

IntDizisi::IntDizisi(int b) : boyut(b) {
    veri = new int[b];
}

IntDizisi::IntDizisi(const IntDizisi& d) : boyut(d.boyut) {
    veri = new int[boyut];
    for (int i = 0; i < boyut; i++) {
        veri[i] = d.veri[i];
    }
}

IntDizisi::~IntDizisi() {
    delete[] veri;
}

void IntDizisi::doldur(int baslangic) {
    for (int i = 0; i < boyut; i++) {
        veri[i] = baslangic + i;
    }
}

void IntDizisi::yazdir() const {
    cout << "{ ";
    for (int i = 0; i < boyut; i++) {
        cout << veri[i] << " ";
    }
    cout << "}" << endl;
}

int IntDizisi::getBoyut() const {
    return boyut;
}

int main() {
    IntDizisi d1(5);
    d1.doldur(10);

    IntDizisi d2 = d1;
    d2.veri[0] = 99;

    d1.yazdir();
    d2.yazdir();

    return 0;
}