#include <iostream>
#include <cmath>
using namespace std;

class BankaHesabi {
    string sahibi;
    double bakiye;
    int hesapNo;
public:
    // Constructor 1: sadece isim  → bakiye=0, hesapNo=rand()
    BankaHesabi(string s) : sahibi(s), bakiye(0), hesapNo(rand()) {}

    // Constructor 2: isim + bakiye → hesapNo=rand()
    BankaHesabi(string s, double b) : sahibi(s), bakiye(b), hesapNo(rand()) {}

    // Constructor 3: isim + bakiye + hesapNo
    BankaHesabi(string s, double b, int h) : sahibi(s), bakiye(b), hesapNo(h) {}

    void bilgiYazdir() const {
        cout << hesapNo << " | " << sahibi << " | " << bakiye << " TL" << endl;
    }
};

int main() {
    BankaHesabi h1("ali");
    BankaHesabi h2("ayse", 500);
    BankaHesabi h3("mehmet", 1000.0, 12345);

    h1.bilgiYazdir();
    h2.bilgiYazdir();
    h3.bilgiYazdir();

    return 0;
}