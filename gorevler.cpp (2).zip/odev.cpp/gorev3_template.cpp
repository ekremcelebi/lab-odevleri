#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    int A[3][3], B[3][3], C[3][3];

    // A matrisini oku
    cout << "A Matrisi:" << endl;
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            cin >> A[i][j];
        }
    }

    // B matrisini oku
    cout << "B Matrisi:" << endl;
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            cin >> B[i][j];
        }
    }

    // Toplama: C = A + B
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            C[i][j] = A[i][j] + B[i][j];
        }
    }

    // C matrisini ekrana yaz
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            //cout << C[i][j] << ", ";
            cout << setw(4) << C[i][j];
        }
        cout << endl;
    }

    // Ana kosegenin toplami (sol-ust'ten sag-alta: C[0][0], C[1][1], C[2][2])
    int toplam = 0;
    for (int i = 0; i < 3; i++) {
        toplam += C[i][i];
    }
    cout << "Toplam: " << toplam << endl;

    return 0;
}