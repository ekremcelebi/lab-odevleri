#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    int n;
    cout << "Kac sayi gireceksiniz? ";
    cin >> n;

    if (n > 100) n = 100;

    int sayilar[100];
    for (int i = 0; i < n; i++) {
        cout << (i + 1) << ". sayiyi giriniz: ";
        cin >> sayilar[i];
    }


    if (n <= 0) {
        cout << "Gecerli bir sayi adedi girmediniz." << endl;
        return 0;
    }

    float toplam = 0;
    int maks = sayilar[0];
    int min = sayilar[0];

    for (int i = 0; i < n; i++) {
        toplam += sayilar[i];
        
        if (sayilar[i] > maks) {
            maks = sayilar[i];
        }
        
        if (sayilar[i] < min) {
            min = sayilar[i];
        }
    }

    cout << "---------------------------------------" << endl;
    cout << "Toplam   : " << toplam << endl;
    cout << "Ortalama : " << fixed << setprecision(2) << (toplam / n) << endl;
    cout << "Maksimum : " << maks << endl; 
    cout << "Minimum  : " << min << endl;  

    return 0;
}