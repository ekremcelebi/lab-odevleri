#ifndef HELPDESK_H
#define HELPDESK_H

void openTicket();
void checkStatus();
void reset();
void contactSupport();
void cancelTicket();

#endif