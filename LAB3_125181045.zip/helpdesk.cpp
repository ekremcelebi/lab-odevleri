#include <iostream>
#include "helpdesk.h"

using namespace std;

void openTicket() {
    cout << "Bilet olusturuldu" << endl;
}

void checkStatus() {
    cout << "Bilet durumu kontrol ediliyor" << endl;
}

void reset() {
    cout << "Sifre sifirlama istegi gonderildi" << endl;
}

void contactSupport() {
    cout << "Destek ile iletisime gecmek icin: helpdesk@bilgi.edu.tr" << endl;
}

void cancelTicket() {
    cout << "Bilet iptal islemi baslatildi." << endl;
}