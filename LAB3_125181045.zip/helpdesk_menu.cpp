#include <iostream>
#include "helpdesk.h"

using namespace std;

int main() {
    int secim;

    cout << "------ Kampus Help Desk ------" << endl;
    cout << "1. Bilet Olustur" << endl;
    cout << "2. Bilet durumunu kontrol et" << endl;
    cout << "3. Sifreyi sifirla" << endl;
    cout << "4. Destek ile iletisime gec" << endl;
    cout << "5. Bilet Iptal Et" << endl;
    cout << "Seciminizi yapin: ";
    cin >> secim;

    switch(secim) {
        case 1: openTicket(); break;
        case 2: checkStatus(); break;
        case 3: reset(); break;
        case 4: contactSupport(); break;
        case 5: cancelTicket(); break;
        default: cout << "Gecersiz secim!" << endl; break;
    }

    return 0;
}

